"""graphdrl package

Top-level package for the project. This file intentionally keeps minimal
initialization. Version and package metadata may be exposed here.
"""

__all__ = ["__version__"]

__version__ = "0.1.0"
